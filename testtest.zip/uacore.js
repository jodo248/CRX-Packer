/* Shared UA logic (background, popup, options) */
(function (g) {
  'use strict';

  const DEFAULT_URL =
    'https://cdn.jsdelivr.net/gh/microlinkhq/top-user-agents@master/src/index.json';

  const PLATFORMS = [
    { id: 'windows',  label: 'Windows',  icon: '🪟' },
    { id: 'macos',    label: 'macOS',    icon: '🍎' },
    { id: 'linux',    label: 'Linux',    icon: '🐧' },
    { id: 'chromeos', label: 'ChromeOS', icon: '💻' },
    { id: 'android',  label: 'Android',  icon: '🤖' },
    { id: 'iphone',   label: 'iPhone',   icon: '📱' },
    { id: 'ipad',     label: 'iPad',     icon: '📲' },
  ];

  const BROWSERS = [
    { id: 'auto',    label: 'Auto (newest)' },
    { id: 'chrome',  label: 'Chrome' },
    { id: 'firefox', label: 'Firefox' },
    { id: 'safari',  label: 'Safari' },
    { id: 'edge',    label: 'Edge' },
    { id: 'opera',   label: 'Opera' },
    { id: 'samsung', label: 'Samsung Internet' },
  ];

  const DEFAULTS = {
    enabled:          true,
    uaPlatform:       'windows',
    uaBrowser:        'auto',
    uaPinned:         '',       // exact UA picked from the list ('' = auto)
    uaMode:           'auto',   // 'auto' (list) | 'custom'
    customUA:         '',
    sourceUrl:        DEFAULT_URL,
    whitelist:        [],
    discourseDetect:  true,
    discourseRemember:true,
    discourseHosts:   [],
    uaList:           [],
    cacheTime:        0,
  };

  // Used only when the list could not be fetched and no custom UA is set.
  const FALLBACKS = {
    windows:  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
    macos:    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
    linux:    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
    chromeos: 'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
    android:  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36',
    iphone:   'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1',
    ipad:     'Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1',
  };

  const AUTO_ORDER = {
    iphone: ['safari', 'chrome', 'firefox', 'edge'],
    ipad:   ['safari', 'chrome', 'firefox', 'edge'],
    _:      ['chrome', 'firefox', 'safari', 'edge', 'opera', 'samsung'],
  };

  function classify(ua) {
    ua = String(ua || '');
    let os = 'other';
    if (/iPhone|iPod/.test(ua)) os = 'iphone';
    else if (/iPad/.test(ua)) os = 'ipad';
    else if (/Android/.test(ua)) os = 'android';
    else if (/CrOS/.test(ua)) os = 'chromeos';
    else if (/Windows/.test(ua)) os = 'windows';
    else if (/Macintosh|Mac OS X/.test(ua)) os = 'macos';
    else if (/Linux|X11/.test(ua)) os = 'linux';

    let browser = 'other', ver = 0, m;
    if ((m = ua.match(/\b(?:Edg|EdgA|EdgiOS|Edge)\/(\d+)/))) { browser = 'edge'; ver = +m[1]; }
    else if ((m = ua.match(/\bOPR\/(\d+)/))) { browser = 'opera'; ver = +m[1]; }
    else if ((m = ua.match(/\bSamsungBrowser\/(\d+)/))) { browser = 'samsung'; ver = +m[1]; }
    else if ((m = ua.match(/\b(?:Firefox|FxiOS)\/(\d+)/))) { browser = 'firefox'; ver = +m[1]; }
    else if ((m = ua.match(/\b(?:Chrome|CriOS)\/(\d+)/))) { browser = 'chrome'; ver = +m[1]; }
    else if ((m = ua.match(/\bVersion\/(\d+)[\d.]*.*Safari\//))) { browser = 'safari'; ver = +m[1]; }
    else if (/Safari\//.test(ua)) { browser = 'safari'; }

    const chromium = /\b(?:Chrome|Chromium)\/\d/.test(ua) && os !== 'iphone' && os !== 'ipad';
    return { os, browser, ver, chromium };
  }

  function filterList(list, platform, browser) {
    return (list || []).filter(ua => {
      if (typeof ua !== 'string') return false;
      const c = classify(ua);
      if (c.os !== platform) return false;
      return !browser || browser === 'auto' || c.browser === browser;
    });
  }

  function newest(cands) {
    let best = cands[0], bv = classify(best).ver;
    for (const ua of cands) {
      const v = classify(ua).ver;
      if (v > bv) { best = ua; bv = v; }
    }
    return best;
  }

  function pickAuto(cands, platform) {
    const order = AUTO_ORDER[platform] || AUTO_ORDER._;
    for (const b of order) {
      const sub = cands.filter(u => classify(u).browser === b);
      if (sub.length) return newest(sub);
    }
    return newest(cands);
  }

  // → { ua, source: 'custom' | 'pinned' | 'list' | 'custom-fallback' | 'fallback' }
  function resolve(st) {
    const custom = (st.customUA || '').trim();
    if (st.uaMode === 'custom' && custom) return { ua: custom, source: 'custom' };

    const list = st.uaList || [];
    const plat = st.uaPlatform;

    if (st.uaPinned && list.includes(st.uaPinned) && classify(st.uaPinned).os === plat) {
      return { ua: st.uaPinned, source: 'pinned' };
    }
    let cands = filterList(list, plat, st.uaBrowser);
    if (cands.length) {
      return { ua: st.uaBrowser === 'auto' ? pickAuto(cands, plat) : newest(cands), source: 'list' };
    }
    cands = filterList(list, plat, 'auto');
    if (cands.length) return { ua: pickAuto(cands, plat), source: 'list' };

    if (custom) return { ua: custom, source: 'custom-fallback' };
    return { ua: FALLBACKS[plat] || FALLBACKS.windows, source: 'fallback' };
  }

  function buildProfile(ua) {
    const c = classify(ua);
    const platformMap = {
      windows: 'Win32', macos: 'MacIntel', linux: 'Linux x86_64', chromeos: 'Linux x86_64',
      android: 'Linux armv81', iphone: 'iPhone', ipad: 'iPad', other: 'Win32',
    };
    const uadPlatform = {
      windows: 'Windows', macos: 'macOS', linux: 'Linux', chromeos: 'Chrome OS',
      android: 'Android', other: 'Windows',
    };
    const mobile = c.os === 'android' ? /Mobile/.test(ua) : (c.os === 'iphone' || c.os === 'ipad');

    let vendor = '';
    if (c.chromium) vendor = 'Google Inc.';
    else if (c.browser === 'safari' || c.os === 'iphone' || c.os === 'ipad') vendor = 'Apple Computer, Inc.';

    let uad = null;
    if (c.chromium) {
      const m = (ua.match(/\bChrome\/(\d+)/) || [])[1] || String(c.ver || 100);
      const brands = [{ brand: 'Chromium', version: m }];
      if (c.browser === 'edge')       brands.push({ brand: 'Microsoft Edge', version: String(c.ver) });
      else if (c.browser === 'opera') brands.push({ brand: 'Opera', version: String(c.ver) });
      else                            brands.push({ brand: 'Google Chrome', version: m });
      brands.push({ brand: 'Not.A/Brand', version: '99' });
      uad = { brands, mobile, platform: uadPlatform[c.os] || 'Windows', full: (ua.match(/\bChrome\/([\d.]+)/) || [])[1] || m };
    }

    return {
      ua,
      appVersion: ua.replace(/^Mozilla\//, ''),
      platform: platformMap[c.os] || 'Win32',
      vendor,
      mobile,
      uad,
      os: c.os,
      browser: c.browser,
    };
  }

  function brandHeader(uad) {
    return uad.brands.map(b => '"' + b.brand + '";v="' + b.version + '"').join(', ');
  }

  function label(ua) {
    const c = classify(ua);
    const b = (BROWSERS.find(x => x.id === c.browser) || { label: 'Browser' }).label;
    const paren = (ua.match(/\(([^)]*)\)/) || [])[1] || '';
    return b + ' ' + (c.ver || '') + ' — ' + paren;
  }

  g.UACore = {
    DEFAULT_URL, PLATFORMS, BROWSERS, DEFAULTS, FALLBACKS,
    classify, filterList, resolve, buildProfile, brandHeader, label,
  };
})(typeof self !== 'undefined' ? self : this);
