/* Fallback page-world injector (used when page CSP blocks inline scripts). */
(function () {
  var s = document.currentScript;
  if (!s) return;
  var cfg;
  try { cfg = JSON.parse(s.getAttribute('data-cfg')); } catch (e) { return; }
  (function (cfg) {
    try {
      var nav = navigator;
      function def(k, v) {
        try {
          Object.defineProperty(nav, k, { get: function () { return v; }, configurable: true, enumerable: true });
        } catch (e) {}
      }
      def('userAgent', cfg.ua);
      def('appVersion', cfg.appVersion);
      def('platform', cfg.platform);
      def('vendor', cfg.vendor);
      if (cfg.mobile) def('maxTouchPoints', 5);

      if (cfg.uad) {
        var u = cfg.uad;
        var brands = u.brands.map(function (b) { return { brand: b.brand, version: b.version }; });
        var data = {
          brands: brands,
          mobile: u.mobile,
          platform: u.platform
        };
        var uaData = {
          get brands() { return brands.slice(); },
          get mobile() { return u.mobile; },
          get platform() { return u.platform; },
          getHighEntropyValues: function (hints) {
            var out = { brands: brands.slice(), mobile: u.mobile, platform: u.platform };
            out.platformVersion = u.platform === 'Windows' ? '10.0.0' : (u.platform === 'macOS' ? '10.15.7' : '');
            out.architecture = u.mobile ? 'arm' : 'x86';
            out.bitness = '64';
            out.model = '';
            out.uaFullVersion = u.full;
            out.fullVersionList = brands.map(function (b) {
              return { brand: b.brand, version: b.brand === 'Not.A/Brand' ? '99.0.0.0' : u.full };
            });
            return Promise.resolve(out);
          },
          toJSON: function () { return data; }
        };
        def('userAgentData', uaData);
      } else if ('userAgentData' in nav) {
        def('userAgentData', undefined);
      }
    } catch (e) {}
  })(cfg);
})();
