/* popup */
'use strict';

const { PLATFORMS, BROWSERS, classify, label } = UACore;
let S = null;
let host = '';
let tabId = null;

const $ = id => document.getElementById(id);

function flash(msg, color) {
  const el = $('status-msg');
  el.textContent = msg;
  el.style.color = color || 'var(--green)';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.textContent = ''; }, 2400);
}

function normHost(h) { return String(h || '').toLowerCase().replace(/^www\./, ''); }

function patch(p, cb) {
  Object.assign(S, p);
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch: p }, () => { if (cb) cb(); });
}

function refreshResolved(cb) {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, st => {
    S = st || S;
    renderUA();
    renderSite();
    if (cb) cb();
  });
}

/* ── platform / browser ─────────────────────────────────── */

function buildPlatformButtons() {
  const g = $('plat-grid');
  g.innerHTML = '';
  PLATFORMS.forEach(p => {
    const b = document.createElement('button');
    b.className = 'type-btn';
    b.dataset.id = p.id;
    b.innerHTML = '<span>' + p.icon + '</span>' + p.label;
    b.addEventListener('click', () => {
      patch({ uaPlatform: p.id, uaPinned: '', uaMode: 'auto' }, () => refreshResolved());
      flash(p.label + ' ✓');
    });
    g.appendChild(b);
  });
  const sel = $('browser-sel');
  sel.innerHTML = BROWSERS.map(b => '<option value="' + b.id + '">' + b.label + '</option>').join('');
  sel.addEventListener('change', () => {
    patch({ uaBrowser: sel.value, uaPinned: '', uaMode: 'auto' }, () => refreshResolved());
    flash('Browser: ' + sel.options[sel.selectedIndex].text);
  });
}

function renderUA() {
  document.querySelectorAll('#plat-grid .type-btn').forEach(b => {
    b.classList.toggle('active', S.uaMode !== 'custom' && b.dataset.id === S.uaPlatform);
  });
  $('browser-sel').value = S.uaBrowser;
  $('browser-sel').disabled = S.uaMode === 'custom';
  const r = S.resolved || {};
  $('ua-preview').textContent = r.ua || '(none)';
  const names = {
    list: 'from jsDelivr list', pinned: 'pinned from list', custom: 'custom UA (manual mode)',
    'custom-fallback': 'custom UA (list had no match)', fallback: 'built-in fallback (list not fetched)',
  };
  $('ua-src').textContent = names[r.source] || '';
}

/* ── site card ──────────────────────────────────────────── */

function inWhitelist() {
  return (S.whitelist || []).some(e => {
    const n = normHost(e);
    return host === n || host.endsWith('.' + n);
  });
}
function isDiscourseHost() {
  return (S.discourseHosts || []).map(normHost).includes(host) ||
         (S.sessionDiscourse || []).includes(host);
}

function renderSite() {
  $('site-name').textContent = host || '(not a web page)';
  const badges = [];
  if (inWhitelist()) badges.push('<span class="badge on">✅ Whitelisted</span>');
  if (isDiscourseHost()) badges.push('<span class="badge dis">💬 Discourse</span>');
  if (!badges.length) badges.push('<span class="badge off">❌ Not listed</span>');
  $('site-badges').innerHTML = badges.join(' ');

  const a = $('site-actions');
  a.innerHTML = '';
  if (!host) return;
  const mk = (html, danger, fn) => {
    const b = document.createElement('button');
    b.className = 'btn';
    if (danger) b.style.cssText = 'color:#e57373;border-color:#3d1515;';
    b.innerHTML = html;
    b.addEventListener('click', fn);
    a.appendChild(b);
  };
  if (inWhitelist()) {
    mk('<span class="icon">➖</span> Remove from whitelist', true, () => {
      const list = (S.whitelist || []).filter(e => normHost(e) !== host);
      patch({ whitelist: list }, () => refreshResolved());
      flash(host + ' removed');
    });
  } else {
    mk('<span class="icon">➕</span> Add to whitelist', false, () => {
      const list = (S.whitelist || []).concat(host);
      patch({ whitelist: list }, () => refreshResolved());
      flash(host + ' added ✓');
    });
  }
  if ((S.discourseHosts || []).map(normHost).includes(host)) {
    mk('<span class="icon">🗑️</span> Forget this Discourse site', true, () => {
      const list = S.discourseHosts.filter(e => normHost(e) !== host);
      patch({ discourseHosts: list }, () => refreshResolved());
      flash('Forgotten');
    });
  }
}

/* ── events ─────────────────────────────────────────────── */

$('toggle-enabled').addEventListener('change', e => {
  patch({ enabled: e.target.checked });
  flash(e.target.checked ? 'Enabled ✓' : 'Disabled');
});
$('toggle-discourse').addEventListener('change', e => {
  patch({ discourseDetect: e.target.checked });
  flash(e.target.checked ? 'Discourse detection on ✓' : 'Discourse detection off');
});
$('btn-options').addEventListener('click', () => { chrome.runtime.openOptionsPage(); window.close(); });
$('btn-reload').addEventListener('click', () => {
  if (tabId != null) chrome.tabs.reload(tabId, { bypassCache: true });
  window.close();
});
$('btn-refresh').addEventListener('click', () => {
  $('btn-refresh').disabled = true;
  flash('Fetching…', 'var(--muted)');
  chrome.runtime.sendMessage({ type: 'REFRESH_UA' }, res => {
    $('btn-refresh').disabled = false;
    if (res && res.ok) { flash(res.count + ' UAs loaded ✓'); refreshResolved(); }
    else flash('Failed: ' + ((res && res.error) || 'no response'), '#e57373');
  });
});

/* ── init ───────────────────────────────────────────────── */

buildPlatformButtons();
chrome.runtime.sendMessage({ type: 'GET_STATE' }, st => {
  S = st || {};
  $('toggle-enabled').checked = !!S.enabled;
  $('toggle-discourse').checked = !!S.discourseDetect;
  renderUA();
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const t = tabs && tabs[0];
    if (t) {
      tabId = t.id;
      try {
        const u = new URL(t.url);
        if (/^https?:$/.test(u.protocol)) host = normHost(u.hostname);
      } catch (_) {}
    }
    renderSite();
  });
});
