/* =========================================================
 * Discourse capability-check bypass — runs SYNCHRONOUSLY
 * before any page script, no async message needed.
 *
 * Discourse's browser-detect.js (browser-detect-*.digested.js)
 * calls CSS.supports() for:
 *   1. relativeColor  → CSS.supports("(color: hsl(from white h s l))")
 *   2. subgrid        → CSS.supports("(grid-template-rows: subgrid)")
 *   3. aspectRatio    → CSS.supports("aspect-ratio: 1")
 * On Kiwi/Chromium 124, relativeColor returns false → sets
 * window.unsupportedBrowser = true → discourse.js throws →
 * page renders the no-JS fallback.
 *
 * Fix: patch CSS.supports in the page world to return true
 * for those specific queries, and block unsupportedBrowser.
 * ========================================================= */
(function discourseCapabilityBypass() {
  var code = '(' + (function () {
    try {
      var _orig = CSS.supports.bind(CSS);
      // Reassign so Discourse's checks pass on Chromium 124
      CSS.supports = function (q, v) {
        var s = (typeof q === 'string' ? q : '') +
                (typeof v === 'string' ? ':' + v : '');
        // relativeColor: "(color: hsl(from white h s l))"
        // subgrid:       "(grid-template-rows: subgrid)"
        // aspectRatio:   "aspect-ratio: 1"  (likely fine but keep safe)
        if (s.indexOf('from ') !== -1 ||
            s.indexOf('subgrid') !== -1) {
          return true;
        }
        return _orig.apply(CSS, arguments);
      };
      // Belt-and-suspenders: prevent unsupportedBrowser from ever being
      // set to true regardless of which check fails
      Object.defineProperty(window, 'unsupportedBrowser', {
        configurable: true,
        get: function () { return undefined; },
        set: function () { /* silently blocked */ }
      });
    } catch (e) {}
  }).toString() + ')();';

  try {
    var el = document.createElement('script');
    el.textContent = code;
    (document.head || document.documentElement).appendChild(el);
    el.remove();
  } catch (e) {
    // CSP blocked inline; try web-accessible fallback (discourse-bypass.js)
    try {
      var f = document.createElement('script');
      f.src = chrome.runtime.getURL('discourse-bypass.js');
      f.onload = f.onerror = function () { f.remove(); };
      (document.head || document.documentElement).appendChild(f);
    } catch (e2) {}
  }
})();

/* =========================================================
 * UA Spoofer — content script (document_start, all_frames)
 *  1. Spoofs navigator.* in the page world on active sites.
 *  2. (top frame) Detects Discourse sites and, if not yet
 *     spoofed, tells the background to start spoofing the
 *     host and reloads the page ONCE (loop-protected).
 * ========================================================= */
(function () {
  'use strict';

  var MAIN = function (cfg) {
    try {
      var nav = navigator;
      function def(k, v) {
        try {
          Object.defineProperty(nav, k, { get: function () { return v; }, configurable: true, enumerable: true });
        } catch (e) {}
      }
      def('userAgent', cfg.ua);
      def('appVersion', cfg.appVersion);
      def('platform', cfg.platform);
      def('vendor', cfg.vendor);
      if (cfg.mobile) def('maxTouchPoints', 5);

      if (cfg.uad) {
        var u = cfg.uad;
        var brands = u.brands.map(function (b) { return { brand: b.brand, version: b.version }; });
        var data = {
          brands: brands,
          mobile: u.mobile,
          platform: u.platform
        };
        var uaData = {
          get brands() { return brands.slice(); },
          get mobile() { return u.mobile; },
          get platform() { return u.platform; },
          getHighEntropyValues: function (hints) {
            var out = { brands: brands.slice(), mobile: u.mobile, platform: u.platform };
            out.platformVersion = u.platform === 'Windows' ? '10.0.0' : (u.platform === 'macOS' ? '10.15.7' : '');
            out.architecture = u.mobile ? 'arm' : 'x86';
            out.bitness = '64';
            out.model = '';
            out.uaFullVersion = u.full;
            out.fullVersionList = brands.map(function (b) {
              return { brand: b.brand, version: b.brand === 'Not.A/Brand' ? '99.0.0.0' : u.full };
            });
            return Promise.resolve(out);
          },
          toJSON: function () { return data; }
        };
        def('userAgentData', uaData);
      } else if ('userAgentData' in nav) {
        def('userAgentData', undefined);
      }
    } catch (e) {}
  };

  var RELOAD_KEY = '__uaspoof_discourse_reload';

  /* ── 1. page-world spoof ─────────────────────────────── */
  function injectSpoof(cfg) {
    var marker = 'data-uas-' + Math.random().toString(36).slice(2, 9);
    var ok = false;
    try {
      var s = document.createElement('script');
      s.textContent = 'document.documentElement.setAttribute("' + marker + '","1");(' +
        MAIN.toString() + ')(' + JSON.stringify(cfg) + ');';
      (document.head || document.documentElement).appendChild(s);
      s.remove();
      ok = document.documentElement.hasAttribute(marker);
      document.documentElement.removeAttribute(marker);
    } catch (e) {}

    if (!ok) {
      // Page CSP blocked the inline script → load packaged file instead.
      try {
        var f = document.createElement('script');
        f.src = chrome.runtime.getURL('inject.js');
        f.setAttribute('data-cfg', JSON.stringify(cfg));
        f.onload = f.onerror = function () { f.remove(); };
        (document.head || document.documentElement).appendChild(f);
      } catch (e) {}
    }
  }

  /* ── 2. Discourse detection ──────────────────────────── */
  var SELECTORS = [
    'meta[name="generator" i][content*="Discourse" i]',
    'meta[name^="discourse" i]',
    'meta[id="data-discourse-setup"]',
    '#data-discourse-setup',
    'discourse-assets',
    'script#data-preloaded',
    'script[data-discourse-entrypoint]',
    'section#d-splash',
    '#d-splash .preloader-image',
    'link[href*="discourse-cdn.com"]',
    'script[src*="discourse-cdn.com"]',
    'script[src*="/assets/discourse"]',
    'link[href*="/stylesheets/color_definitions_"]',
    'link[href*="/stylesheets/desktop_"][data-target]',
    'link[data-target][data-theme-id]',
    'body.crawler #main-outlet',
    '.powered-by-link a[href*="discourse.org"]',
    'a[href*="discourse.org/about#browser"]'
  ].join(',');

  function isDiscourse() {
    try { return !!document.querySelector(SELECTORS); } catch (e) { return false; }
  }

  function watchDiscourse(onFound) {
    var done = false, timer = 0, obs = null;

    function found() {
      if (done) return;
      done = true;
      if (obs) obs.disconnect();
      onFound();
    }
    function check() { if (!done && isDiscourse()) found(); }

    check();
    if (done) return;

    try {
      obs = new MutationObserver(function () {
        if (timer) return;
        timer = setTimeout(function () { timer = 0; check(); }, 40);
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) {}

    document.addEventListener('DOMContentLoaded', check);
    window.addEventListener('load', function () {
      check();
      if (obs) obs.disconnect();
    });
  }

  function guardRead() {
    try { return parseInt(sessionStorage.getItem(RELOAD_KEY), 10) || 0; } catch (e) {}
    try { return parseInt(localStorage.getItem(RELOAD_KEY + '_ls'), 10) || 0; } catch (e) {}
    return 99;                       // no storage → never reload
  }
  function guardSet(n) {
    try { sessionStorage.setItem(RELOAD_KEY, String(n)); return true; } catch (e) {}
    try { localStorage.setItem(RELOAD_KEY + '_ls', String(n)); return true; } catch (e) {}
    return false;
  }
  function guardClear() {
    try { sessionStorage.removeItem(RELOAD_KEY); } catch (e) {}
    try { localStorage.removeItem(RELOAD_KEY + '_ls'); } catch (e) {}
  }

  /* ── main ────────────────────────────────────────────── */
  chrome.runtime.sendMessage({ type: 'GET_SPOOF_INFO' }, function (info) {
    if (chrome.runtime.lastError || !info) return;
    if (info.enabled && info.active && info.cfg) injectSpoof(info.cfg);

    var isTop = window === window.top;
    var isHtml = !document.contentType || /html/i.test(document.contentType);
    if (!isTop || !isHtml || !info.detect) return;

    watchDiscourse(function () {
      chrome.runtime.sendMessage({ type: 'DISCOURSE_FOUND' }, function (res) {
        if (chrome.runtime.lastError || !res || !res.ok) return;

        if (info.active) {           // already spoofed → all good, reset guard
          guardClear();
          return;
        }
        if (!res.allowReload) return;
        if (guardRead() >= 1) return;     // already reloaded once, don't loop
        if (!guardSet(1)) return;
        location.reload();
      });
    });
  });
})();
