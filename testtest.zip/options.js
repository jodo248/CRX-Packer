/* options */
'use strict';

const { PLATFORMS, BROWSERS, DEFAULTS, DEFAULT_URL, filterList, resolve, label, classify } = UACore;
const $ = id => document.getElementById(id);
let S = null;
let importData = null;

function showStatus(msg, ok) {
  const el = $('status');
  el.textContent = msg;
  el.className = ok ? 'ok' : 'err';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.className = ''; el.textContent = ''; }, 4500);
}

function fmtTime(ts, count) {
  if (!ts) return 'Never fetched.';
  const ago = Math.round((Date.now() - ts) / 60000);
  const when = ago < 60 ? ago + ' min ago' : ago < 1440 ? Math.round(ago / 60) + ' h ago'
    : new Date(ts).toLocaleDateString();
  return count + ' UAs cached · fetched ' + when + '.';
}

function lines(id) {
  return $(id).value.split('\n')
    .map(l => l.trim().toLowerCase().replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').replace(/[\/?#].*$/, ''))
    .filter(Boolean);
}

/* ── form <-> state ─────────────────────────────────────── */

function formState() {
  return {
    enabled: $('opt-enabled').checked,
    uaMode: document.querySelector('input[name="uaMode"]:checked').value,
    uaPlatform: document.querySelector('input[name="uaPlatform"]:checked').value,
    uaBrowser: $('browser-sel').value,
    uaPinned: $('pin-sel').value,
    customUA: $('custom-ua').value.trim(),
    sourceUrl: $('source-url').value.trim() || DEFAULT_URL,
    whitelist: lines('whitelist'),
    discourseDetect: $('opt-dis-detect').checked,
    discourseRemember: $('opt-dis-remember').checked,
    discourseHosts: lines('dis-hosts'),
  };
}

function rebuildPins() {
  const f = formState();
  const cands = filterList(S.uaList, f.uaPlatform, f.uaBrowser);
  const sel = $('pin-sel');
  const cur = sel.value || S.uaPinned;
  sel.innerHTML = '<option value="">Auto (newest match)</option>' +
    cands.map(u => '<option value="' + u.replace(/"/g, '&quot;') + '">' + label(u).replace(/</g, '&lt;') + '</option>').join('');
  sel.value = cands.includes(cur) ? cur : '';
}

function updatePreview() {
  const f = formState();
  const r = resolve(Object.assign({}, S, f));
  $('ua-resolved').textContent = r.ua;
  const names = {
    list: 'Source: fetched list', pinned: 'Source: pinned UA from list', custom: 'Source: your custom UA',
    'custom-fallback': 'Source: your custom UA (list had no match)', fallback: 'Source: built-in fallback (list not fetched yet)',
  };
  $('ua-source').textContent = names[r.source] || '';
  $('auto-box').style.opacity = f.uaMode === 'custom' ? '.45' : '1';
}

function render(st) {
  S = st;
  $('opt-enabled').checked = !!S.enabled;
  $('enabled-label').textContent = S.enabled ? 'Enabled' : 'Disabled';
  document.querySelector('input[name="uaMode"][value="' + (S.uaMode || 'auto') + '"]').checked = true;

  const pg = $('plat-group');
  pg.innerHTML = PLATFORMS.map(p =>
    '<label><input type="radio" name="uaPlatform" value="' + p.id + '"> ' + p.icon + ' ' + p.label + '</label>').join('');
  document.querySelector('input[name="uaPlatform"][value="' + S.uaPlatform + '"]').checked = true;

  $('browser-sel').innerHTML = BROWSERS.map(b => '<option value="' + b.id + '">' + b.label + '</option>').join('');
  $('browser-sel').value = S.uaBrowser;

  $('pin-sel').value = S.uaPinned || '';
  rebuildPins();
  $('pin-sel').value = (S.uaList || []).includes(S.uaPinned) ? S.uaPinned : '';

  $('custom-ua').value = S.customUA || '';
  $('source-url').value = S.sourceUrl || DEFAULT_URL;
  $('whitelist').value = (S.whitelist || []).join('\n');
  $('opt-dis-detect').checked = !!S.discourseDetect;
  $('opt-dis-remember').checked = !!S.discourseRemember;
  $('dis-hosts').value = (S.discourseHosts || []).join('\n');
  $('cache-time').textContent = fmtTime(S.cacheTime, (S.uaList || []).length);
  updatePreview();
}

function load(cb) {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, st => { render(st || Object.assign({}, DEFAULTS)); if (cb) cb(); });
}

/* ── events ─────────────────────────────────────────────── */

$('opt-enabled').addEventListener('change', e => { $('enabled-label').textContent = e.target.checked ? 'Enabled' : 'Disabled'; });
document.addEventListener('change', e => {
  const n = e.target.name || e.target.id;
  if (n === 'uaPlatform' || n === 'browser-sel') { $('pin-sel').value = ''; rebuildPins(); }
  if (['uaMode', 'uaPlatform', 'browser-sel', 'pin-sel'].includes(n)) updatePreview();
});
$('custom-ua').addEventListener('input', updatePreview);

$('btn-save').addEventListener('click', () => {
  const patch = formState();
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch }, res => {
    if (chrome.runtime.lastError || !res || !res.ok) return showStatus('❌ Save failed — background not responding.', false);
    load();
    showStatus('✅ Saved. ' + patch.whitelist.length + ' whitelisted site(s), ' + patch.discourseHosts.length + ' Discourse host(s).', true);
  });
});

$('btn-clear-wl').addEventListener('click', () => {
  if (!confirm('Clear all whitelisted sites?')) return;
  $('whitelist').value = '';
  showStatus('Whitelist cleared — click Save to apply.', true);
});

$('btn-default-url').addEventListener('click', () => { $('source-url').value = DEFAULT_URL; });

$('btn-refresh').addEventListener('click', () => {
  const btn = $('btn-refresh');
  btn.disabled = true; btn.textContent = '⏳ Fetching…';
  // save URL first so the background uses what's in the box
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch: { sourceUrl: $('source-url').value.trim() || DEFAULT_URL } }, () => {
    chrome.runtime.sendMessage({ type: 'REFRESH_UA' }, res => {
      btn.disabled = false; btn.textContent = '🔄 Refresh UA list now';
      if (res && res.ok) {
        load();
        showStatus('✅ ' + res.count + ' user agents loaded.', true);
      } else {
        showStatus('❌ Refresh failed: ' + ((res && res.error) || 'no response') + ' — the old cache (or your custom UA) stays in use.', false);
      }
    });
  });
});

/* ── export / import ────────────────────────────────────── */

$('btn-export').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, st => {
    const out = { _meta: { app: 'ua-spoofer', schema: 2, exported: new Date().toISOString() } };
    Object.keys(DEFAULTS).forEach(k => { out[k] = st[k]; });
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'ua-spoofer-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    showStatus('✅ Exported.', true);
  });
});

$('import-file').addEventListener('change', e => {
  importData = null; $('btn-import').disabled = true;
  const f = e.target.files[0];
  if (!f) return;
  const rd = new FileReader();
  rd.onload = () => {
    try {
      importData = JSON.parse(rd.result);
      $('btn-import').disabled = false;
      showStatus('File loaded — click “Import selected file”.', true);
    } catch (err) { showStatus('❌ Not valid JSON: ' + err.message, false); }
  };
  rd.readAsText(f);
});

const strList = a => Array.isArray(a) ? a.filter(x => typeof x === 'string').slice(0, 5000) : null;

function sanitize(d) {
  if (!d || typeof d !== 'object' || Array.isArray(d)) throw new Error('unexpected file structure');
  const o = {};
  if (typeof d.enabled === 'boolean') o.enabled = d.enabled;
  if (PLATFORMS.some(p => p.id === d.uaPlatform)) o.uaPlatform = d.uaPlatform;
  else if (d.mobileType === 'iphone' || d.mobileType === 'android') o.uaPlatform = d.mobileType; // v1 backups
  if (BROWSERS.some(b => b.id === d.uaBrowser)) o.uaBrowser = d.uaBrowser;
  if (d.uaMode === 'auto' || d.uaMode === 'custom') o.uaMode = d.uaMode;
  if (typeof d.uaPinned === 'string') o.uaPinned = d.uaPinned.slice(0, 600);
  if (typeof d.customUA === 'string') o.customUA = d.customUA.slice(0, 600);
  if (typeof d.sourceUrl === 'string' && /^https?:\/\//i.test(d.sourceUrl)) o.sourceUrl = d.sourceUrl.slice(0, 1000);
  if (typeof d.discourseDetect === 'boolean') o.discourseDetect = d.discourseDetect;
  if (typeof d.discourseRemember === 'boolean') o.discourseRemember = d.discourseRemember;
  const wl = strList(d.whitelist), dh = strList(d.discourseHosts), ul = strList(d.uaList);
  if (wl) o.whitelist = wl;
  if (dh) o.discourseHosts = dh;
  if (ul && ul.length) { o.uaList = ul.filter(u => u.length > 10 && u.length < 600); }
  if (typeof d.cacheTime === 'number') o.cacheTime = d.cacheTime;
  if (!Object.keys(o).length) throw new Error('no recognisable settings found');
  return o;
}

$('btn-import').addEventListener('click', () => {
  let p;
  try { p = sanitize(importData); } catch (err) { return showStatus('❌ Import failed: ' + err.message, false); }
  const merge = $('import-merge').checked;
  if (!merge) {
    // replace: anything missing from the file goes back to default
    Object.keys(DEFAULTS).forEach(k => { if (!(k in p) && k !== 'uaList' && k !== 'cacheTime') p[k] = JSON.parse(JSON.stringify(DEFAULTS[k])); });
  } else {
    p.whitelist = Array.from(new Set((S.whitelist || []).concat(p.whitelist || [])));
    p.discourseHosts = Array.from(new Set((S.discourseHosts || []).concat(p.discourseHosts || [])));
  }
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch: p }, res => {
    if (!res || !res.ok) return showStatus('❌ Import failed — background not responding.', false);
    load();
    showStatus('✅ Imported ' + Object.keys(p).length + ' setting(s) (' + (merge ? 'merged' : 'replaced') + ').', true);
  });
});

$('btn-reset').addEventListener('click', () => {
  if (!confirm('Reset ALL settings (including whitelist and Discourse hosts) to defaults?')) return;
  const p = JSON.parse(JSON.stringify(DEFAULTS));
  delete p.uaList; delete p.cacheTime;     // keep the cached list
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch: p }, () => { load(); showStatus('✅ Reset to defaults.', true); });
});

load();
