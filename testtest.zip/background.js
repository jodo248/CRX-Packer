/* =========================================================
 * UA Spoofer — background (persistent, MV2)
 * ========================================================= */
'use strict';

/* uacore.js is loaded before this file (see manifest background.scripts) */
const { DEFAULTS, DEFAULT_URL, resolve, buildProfile, brandHeader, classify } = UACore;

const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const KEYS = Object.keys(DEFAULTS);

let state = JSON.parse(JSON.stringify(DEFAULTS));
let C = { wl: new Set(), dh: new Set(), profile: null, source: 'fallback' };
const sessionDiscourse = new Set();   // hosts detected this browser session
const reloadGuard = new Map();        // tabId|host -> timestamp

/* ── helpers ─────────────────────────────────────────────── */

function normHost(h) { return String(h || '').trim().toLowerCase().replace(/^www\./, ''); }
function hostOf(url) { try { return normHost(new URL(url).hostname); } catch (_) { return ''; } }

function hostInSet(host, set) {
  let h = host;
  while (h) {
    if (set.has(h)) return true;
    const i = h.indexOf('.');
    if (i < 0) return false;
    h = h.slice(i + 1);
  }
  return false;
}

function cleanList(arr) {
  return Array.from(new Set((arr || [])
    .map(s => normHost(String(s).replace(/^[a-z]+:\/\//i, '').replace(/[\/?#].*$/, '')))
    .filter(Boolean)));
}

function recompute() {
  C.wl = new Set(cleanList(state.whitelist));
  C.dh = new Set(cleanList(state.discourseHosts));
  const r = resolve(state);
  C.source = r.source;
  C.profile = r.ua ? buildProfile(r.ua) : null;
}

function isActiveFor(url) {
  if (!state.enabled || !C.profile) return false;
  const h = hostOf(url);
  if (!h) return false;
  return hostInSet(h, C.wl) || C.dh.has(h) || sessionDiscourse.has(h);
}

/* ── storage ─────────────────────────────────────────────── */

function loadState(cb) {
  chrome.storage.local.get(null, data => {
    const patch = {};
    const remove = [];
    // migrate v1 → v2
    if ('mobileType' in data) {
      if (!data.uaPlatform) patch.uaPlatform = data.mobileType === 'iphone' ? 'iphone' : 'android';
      remove.push('mobileType', 'uaAndroid', 'uaIphone');
    }
    for (const k of KEYS) if (k in data) state[k] = data[k];
    Object.assign(state, patch);
    if (Object.keys(patch).length) chrome.storage.local.set(patch);
    if (remove.length) chrome.storage.local.remove(remove);
    recompute();
    if (cb) cb();
  });
}

function saveState(patch, cb) {
  const clean = {};
  for (const k of KEYS) if (k in patch) clean[k] = patch[k];
  Object.assign(state, clean);
  recompute();
  chrome.storage.local.set(clean, cb);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  let touched = false;
  for (const k of Object.keys(changes)) {
    if (!KEYS.includes(k)) continue;
    const v = changes[k].newValue;
    state[k] = v === undefined ? JSON.parse(JSON.stringify(DEFAULTS[k])) : v;
    touched = true;
  }
  if (touched) recompute();
});

/* ── UA list ─────────────────────────────────────────────── */

function refreshCache(cb) {
  const url = (state.sourceUrl || '').trim() || DEFAULT_URL;
  fetch(url, { cache: 'no-store' })
    .then(r => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(data => {
      let arr = Array.isArray(data) ? data
        : (data && (data.userAgents || data.agents || data.list)) || null;
      if (!Array.isArray(arr)) throw new Error('unexpected JSON format (need an array of strings)');
      arr = arr.filter(u => typeof u === 'string' && u.length > 10 && u.length < 600);
      if (!arr.length) throw new Error('empty list');
      saveState({ uaList: arr, cacheTime: Date.now() }, () => cb && cb({ ok: true, count: arr.length }));
    })
    .catch(err => {
      console.warn('[UA Spoofer] Refresh failed:', err.message);
      if (cb) cb({ ok: false, error: err.message });
    });
}

/* ── webRequest: HTTP header spoofing ────────────────────── */

chrome.webRequest.onBeforeSendHeaders.addListener(
  details => {
    if (!isActiveFor(details.url)) return;
    const p = C.profile;

    const headers = (details.requestHeaders || []).filter(h => {
      const n = h.name.toLowerCase();
      return n !== 'user-agent' && n.indexOf('sec-ch-ua') !== 0;
    });
    headers.push({ name: 'User-Agent', value: p.ua });

    // Chromium-based UAs keep client hints consistent; others drop them.
    if (p.uad) {
      headers.push({ name: 'sec-ch-ua', value: brandHeader(p.uad) });
      headers.push({ name: 'sec-ch-ua-mobile', value: p.uad.mobile ? '?1' : '?0' });
      headers.push({ name: 'sec-ch-ua-platform', value: '"' + p.uad.platform + '"' });
    }
    return { requestHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders', 'extraHeaders']
);

/* ── messages ────────────────────────────────────────────── */

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  switch (msg && msg.type) {
    case 'GET_SPOOF_INFO': {
      const url = sender.url || (sender.tab && sender.tab.url) || '';
      const active = isActiveFor(url);
      reply({
        enabled: state.enabled,
        active,
        cfg: active ? C.profile : null,
        detect: !!(state.enabled && state.discourseDetect),
      });
      return true;
    }

    case 'DISCOURSE_FOUND': {
      const url = sender.url || (sender.tab && sender.tab.url) || '';
      const host = hostOf(url);
      if (!host || !state.enabled || !state.discourseDetect) { reply({ ok: false }); return true; }
      sessionDiscourse.add(host);
      if (state.discourseRemember && !C.dh.has(host)) {
        saveState({ discourseHosts: cleanList(state.discourseHosts.concat(host)) });
      }
      const gk = (sender.tab ? sender.tab.id : '?') + '|' + host;
      const last = reloadGuard.get(gk) || 0;
      const allowReload = Date.now() - last > 30000;
      if (allowReload) reloadGuard.set(gk, Date.now());
      reply({ ok: true, allowReload });
      return true;
    }

    case 'GET_STATE': {
      const r = resolve(state);
      reply(Object.assign({}, state, { resolved: r, sessionDiscourse: Array.from(sessionDiscourse) }));
      return true;
    }

    case 'SET_STATE':
      saveState(msg.patch || {}, () => reply({ ok: true }));
      return true;

    case 'REFRESH_UA':
      refreshCache(res => reply(res));
      return true;
  }
});

/* ── init ────────────────────────────────────────────────── */

loadState(() => {
  const stale = !state.uaList.length || (Date.now() - state.cacheTime > CACHE_TTL_MS);
  if (stale) refreshCache();
});
setInterval(() => {
  if (Date.now() - state.cacheTime > CACHE_TTL_MS) refreshCache();
}, 6 * 60 * 60 * 1000);
