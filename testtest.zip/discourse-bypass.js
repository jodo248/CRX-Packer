/* discourse-bypass.js — web-accessible fallback
 * Loaded when the page's CSP blocks the inline <script> version.
 * Runs in the PAGE WORLD; patches CSS.supports and blocks
 * window.unsupportedBrowser so Discourse's browser-detect.js
 * does not gate out Chromium 124 / Kiwi Browser.
 */
(function () {
  try {
    var _orig = CSS.supports.bind(CSS);
    CSS.supports = function (q, v) {
      var s = (typeof q === 'string' ? q : '') +
              (typeof v === 'string' ? ':' + v : '');
      if (s.indexOf('from ') !== -1 || s.indexOf('subgrid') !== -1) {
        return true;
      }
      return _orig.apply(CSS, arguments);
    };
    Object.defineProperty(window, 'unsupportedBrowser', {
      configurable: true,
      get: function () { return undefined; },
      set: function () {}
    });
  } catch (e) {}
})();
