/*
 * background.js — Google Cookie Wipe
 *
 * Receives a "wipeAndReload" message from the content script.
 * Uses chrome.cookies (which CAN delete httpOnly cookies) to remove
 * every cookie for *.google.com, then tells the content script to
 * do the form-submit reload so the page navigates cleanly.
 *
 * API surface: MV2 background page — works in both Chrome and Firefox.
 * Firefox exposes both "browser.*" and "chrome.*" in background pages;
 * Chrome only has "chrome.*".  We prefer "browser.*" (promise-based)
 * when available, fall back to chrome.* (callback-based) otherwise.
 */

const api = typeof browser !== 'undefined' ? browser : chrome;

const GOOGLE_DOMAINS = [
  'google.com',
  '.google.com',
  'www.google.com',
];

const PATHS = ['/', '/search'];

// ── helpers ──────────────────────────────────────────────────────────────────

function removeCookie(name, domain, path) {
  // chrome.cookies.remove needs the full "url" that would match the cookie.
  const scheme = domain.includes('google.com') ? 'https' : 'https';
  const host   = domain.startsWith('.') ? 'www' + domain : domain;
  const url    = `${scheme}://${host}${path}`;

  return new Promise(resolve => {
    // Use the native chrome.* here because we need it to work on Chrome 90+
    // and Firefox simultaneously; browser.cookies.remove returns a promise,
    // chrome.cookies.remove uses a callback — wrap uniformly.
    if (typeof browser !== 'undefined' && browser.cookies) {
      browser.cookies.remove({ url, name }).then(resolve).catch(resolve);
    } else {
      chrome.cookies.remove({ url, name }, resolve);
    }
  });
}

function getAllGoogleCookies() {
  return new Promise(resolve => {
    if (typeof browser !== 'undefined' && browser.cookies) {
      browser.cookies.getAll({ domain: 'google.com' }).then(resolve).catch(() => resolve([]));
    } else {
      chrome.cookies.getAll({ domain: 'google.com' }, cookies => resolve(cookies || []));
    }
  });
}

// ── main wipe logic ───────────────────────────────────────────────────────────

async function wipeAllGoogleCookies() {
  const cookies = await getAllGoogleCookies();
  if (!cookies.length) return 0;

  const tasks = [];

  cookies.forEach(cookie => {
    // Build the full URL chrome.cookies.remove needs
    const scheme = cookie.secure ? 'https' : 'http';
    const host   = cookie.domain.startsWith('.')
                   ? 'www' + cookie.domain   // .google.com → www.google.com
                   : cookie.domain;
    const url    = `${scheme}://${host}${cookie.path}`;

    const removeP = new Promise(resolve => {
      if (typeof browser !== 'undefined' && browser.cookies) {
        browser.cookies.remove({ url, name: cookie.name })
          .then(resolve).catch(resolve);
      } else {
        chrome.cookies.remove({ url, name: cookie.name }, resolve);
      }
    });
    tasks.push(removeP);
  });

  await Promise.all(tasks);
  return cookies.length;
}

// ── message listener ──────────────────────────────────────────────────────────

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'wipeAndReload') return false;

  wipeAllGoogleCookies().then(count => {
    // Tell the content script how many cookies were wiped so it can
    // decide whether to do the form-submit reload.
    sendResponse({ wiped: count });
  });

  return true; // keep channel open for async sendResponse
});
