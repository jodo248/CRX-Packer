/*
 * content.js — Google Cookie Wipe
 * Runs at document_end on www.google.com/search*
 *
 * Flow
 * ────
 * Phase 1  (flag absent)
 *   – Ask background to wipe all cookies via chrome.cookies API
 *     (this catches httpOnly cookies that document.cookie cannot touch)
 *   – Set sessionStorage flag
 *   – Reload via form submit (preserves search query, fires fresh GET)
 *
 * Phase 2  (flag present)
 *   – Remove flag immediately (no bloat)
 *   – Verify: re-fetch cookie list from background; if any remain that
 *     weren't there before the wipe (i.e. Google immediately re-set them
 *     on the reload response), that's fine — we only care that the ones
 *     we knew about are gone.  Practically: just finish, job is done.
 *   – No second reload needed.
 *
 * The sessionStorage flag lives only for this tab's session and is
 * deleted in phase 2, so the tab never loops.
 */

(function () {
  'use strict';

  const FLAG   = 'gcw_wipe_done';
  const api    = typeof browser !== 'undefined' ? browser : chrome;

  // ── form-submit reload (same method as the userscript) ──────────────────

  function submitViaSearchForm() {
    const q    = new URL(window.location.href).searchParams.get('q') || '';
    const form = document.getElementById('tsf')
              || document.querySelector('form[action="/search"]');

    if (!form) {
      // Fallback: no form found, plain reload
      window.location.reload();
      return;
    }

    const field = form.querySelector('textarea[name="q"]')
               || form.querySelector('input[name="q"]');

    if (field) {
      const proto = field instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(field, q);
      field.dispatchEvent(new Event('input',  { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
    }

    form.submit();
  }

  // ── Phase 1 ──────────────────────────────────────────────────────────────

  if (!sessionStorage.getItem(FLAG)) {
    sessionStorage.setItem(FLAG, '1');

    api.runtime.sendMessage({ action: 'wipeAndReload' }, response => {
      // response = { wiped: N }  — N cookies were deleted (including httpOnly)
      // Regardless of count, do the form-submit to load a fresh cookieless page
      submitViaSearchForm();
    });

    return; // don't fall into phase 2
  }

  // ── Phase 2 ──────────────────────────────────────────────────────────────

  // Remove flag right away — no bloat on subsequent navigations
  sessionStorage.removeItem(FLAG);

  // Nothing else to do: the wipe already happened before this load.
  // The page is now running without the old cookies.

})();
