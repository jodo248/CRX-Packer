'use strict';

let _state = null;

/* ── Helpers ──────────────────────────────────────────────── */

function showStatus(msg, ok) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = ok ? 'ok' : 'err';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.className = ''; el.textContent = ''; }, 3000);
}

function fmtTime(ts) {
  if (!ts) return 'Never fetched.';
  const d = new Date(ts);
  const ago = Math.round((Date.now() - ts) / 60000);
  if (ago < 60)   return `Cached ${ago} minute${ago !== 1 ? 's' : ''} ago (${d.toLocaleTimeString()}).`;
  if (ago < 1440) return `Cached ${Math.round(ago/60)} hour${Math.round(ago/60) !== 1 ? 's' : ''} ago.`;
  return `Cached on ${d.toLocaleDateString()}.`;
}

function renderState(s) {
  _state = s;

  // Enabled toggle
  document.getElementById('opt-enabled').checked = !!s.enabled;
  document.getElementById('enabled-label').textContent = s.enabled ? 'Enabled' : 'Disabled';

  // UA type
  const radio = document.querySelector(`input[name="mobileType"][value="${s.mobileType || 'android'}"]`);
  if (radio) radio.checked = true;

  // Whitelist textarea
  document.getElementById('whitelist').value = (s.whitelist || []).join('\n');

  // UA previews
  document.getElementById('ua-android').textContent = s.uaAndroid || '(not yet fetched)';
  document.getElementById('ua-iphone').textContent  = s.uaIphone  || '(not yet fetched)';
  document.getElementById('cache-time').textContent  = fmtTime(s.cacheTime);
}

function parseWhitelist() {
  return document.getElementById('whitelist').value
    .split('\n')
    .map(l => l.trim().toLowerCase().replace(/^www\./, '').replace(/\/.*$/, ''))
    .filter(Boolean);
}

/* ── Event handlers ───────────────────────────────────────── */

document.getElementById('opt-enabled').addEventListener('change', e => {
  document.getElementById('enabled-label').textContent = e.target.checked ? 'Enabled' : 'Disabled';
});

document.getElementById('btn-save').addEventListener('click', () => {
  const type = document.querySelector('input[name="mobileType"]:checked')?.value || 'android';
  const patch = {
    enabled:    document.getElementById('opt-enabled').checked,
    mobileType: type,
    whitelist:  parseWhitelist(),
  };
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch }, res => {
    if (chrome.runtime.lastError || !res?.ok) {
      showStatus('❌ Save failed — background not responding.', false);
    } else {
      Object.assign(_state, patch);
      showStatus(`✅ Saved. ${patch.whitelist.length} site${patch.whitelist.length !== 1 ? 's' : ''} whitelisted.`, true);
    }
  });
});

document.getElementById('btn-clear-wl').addEventListener('click', () => {
  if (!confirm('Clear all whitelisted sites?')) return;
  document.getElementById('whitelist').value = '';
  showStatus('Whitelist cleared — click Save to apply.', true);
});

document.getElementById('btn-refresh').addEventListener('click', () => {
  const btn = document.getElementById('btn-refresh');
  btn.disabled = true;
  btn.textContent = '⏳ Fetching…';
  chrome.runtime.sendMessage({ type: 'REFRESH_UA' }, data => {
    btn.disabled = false;
    btn.textContent = '🔄 Refresh UA list now';
    if (data && (data.uaAndroid || data.uaIphone)) {
      document.getElementById('ua-android').textContent = data.uaAndroid || '—';
      document.getElementById('ua-iphone').textContent  = data.uaIphone  || '—';
      document.getElementById('cache-time').textContent  = fmtTime(Date.now());
      showStatus('✅ UA list refreshed.', true);
    } else {
      showStatus('❌ Refresh failed — check the browser console.', false);
    }
  });
});

/* ── Init ─────────────────────────────────────────────────── */

chrome.runtime.sendMessage({ type: 'GET_STATE' }, state => {
  renderState(state || {});
});
