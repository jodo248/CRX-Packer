/* =========================================================
 * UA Spoofer — content script (document_start, all_frames)
 * =========================================================
 * Asks the background for the active UA and, if this page
 * is whitelisted, injects a tiny inline <script> into the
 * page's own JS world to override navigator.userAgent etc.
 *
 * The HTTP header is already handled by background.js.
 * This script covers the JS side so in-page UA checks also
 * see the spoofed string.
 * ========================================================= */

(function () {
  'use strict';

  chrome.runtime.sendMessage({ type: 'GET_SPOOF_INFO' }, function (info) {
    if (chrome.runtime.lastError || !info) return;
    if (!info.enabled || !info.whitelisted || !info.ua) return;

    const ua       = info.ua;
    const isIphone = info.mobileType === 'iphone';

    // Build a self-executing script that runs in the PAGE world.
    // We JSON.stringify the ua string so any quotes / slashes are escaped.
    const code = [
      '(function(){',
      '  "use strict";',
      '  var ua=' + JSON.stringify(ua) + ';',
      '  var isIphone=' + (isIphone ? 'true' : 'false') + ';',
      '  var props={',
      '    userAgent:  ua,',
      '    platform:   isIphone ? "iPhone" : "Linux armv8l",',
      '    appVersion: ua.replace(/^Mozilla\\//, ""),',
      '    vendor:     isIphone ? "Apple Computer, Inc." : "Google Inc."',
      '  };',
      '  for(var k in props){',
      '    try{',
      '      Object.defineProperty(navigator,k,{',
      '        get:function(v){return function(){return v;};}(props[k]),',
      '        configurable:true',
      '      });',
      '    }catch(e){}',
      '  }',
      '})();',
    ].join('\n');

    var s = document.createElement('script');
    s.textContent = code;
    // Append to <html> (always exists at document_start) so it runs
    // before any deferred/async page scripts.
    (document.head || document.documentElement).appendChild(s);
    s.parentNode && s.parentNode.removeChild(s);
  });
})();
