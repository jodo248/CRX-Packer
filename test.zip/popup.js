'use strict';

let _state = null;
let _currentHost = '';

function flash(msg, color) {
  const el = document.getElementById('status-msg');
  el.textContent = msg;
  el.style.color = color || 'var(--green)';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.textContent = ''; }, 2200);
}

function setEnabled(val) {
  document.getElementById('toggle-enabled').checked = val;
}

function setType(type) {
  document.querySelectorAll('.type-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.type === type);
  });
  updateUAPreview(type);
}

function updateUAPreview(type) {
  if (!_state) return;
  const ua = type === 'iphone' ? _state.uaIphone : _state.uaAndroid;
  document.getElementById('ua-preview').textContent = ua || '(no UA cached — click Refresh)';
}

function updateSiteCard(whitelist) {
  const badge    = document.getElementById('site-badge');
  const nameEl   = document.getElementById('site-name');
  const actionsEl = document.getElementById('site-actions');

  nameEl.textContent = _currentHost || '(unknown)';

  const listed = whitelist.some(e => {
    const norm = e.replace(/^www\./, '');
    return _currentHost === norm || _currentHost.endsWith('.' + norm);
  });

  if (listed) {
    badge.textContent  = '✅ Whitelisted';
    badge.className    = 'badge on';
    actionsEl.innerHTML =
      '<button class="btn" id="btn-remove-site" style="color:#e57373;border-color:#3d1515;">' +
      '<span class="icon">➖</span> Remove this site</button>';
    document.getElementById('btn-remove-site').addEventListener('click', removeSite);
  } else {
    badge.textContent  = '❌ Not listed';
    badge.className    = 'badge off';
    actionsEl.innerHTML =
      '<button class="btn" id="btn-add-site">' +
      '<span class="icon">➕</span> Add this site to whitelist</button>';
    document.getElementById('btn-add-site').addEventListener('click', addSite);
  }
}

function sendPatch(patch, cb) {
  chrome.runtime.sendMessage({ type: 'SET_STATE', patch }, cb);
  Object.assign(_state, patch);
}

/* ── Actions ─────────────────────────────────────────────── */

document.getElementById('toggle-enabled').addEventListener('change', e => {
  sendPatch({ enabled: e.target.checked });
  flash(e.target.checked ? 'Enabled ✓' : 'Disabled');
});

document.querySelectorAll('.type-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const t = btn.dataset.type;
    setType(t);
    sendPatch({ mobileType: t });
    flash('Switched to ' + t.toUpperCase() + ' ✓');
  });
});

document.getElementById('btn-options').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

document.getElementById('btn-refresh').addEventListener('click', () => {
  document.getElementById('btn-refresh').disabled = true;
  flash('Fetching…', 'var(--muted)');
  chrome.runtime.sendMessage({ type: 'REFRESH_UA' }, data => {
    document.getElementById('btn-refresh').disabled = false;
    if (data && (data.uaAndroid || data.uaIphone)) {
      Object.assign(_state, data);
      updateUAPreview(_state.mobileType);
      flash('UA list refreshed ✓');
    } else {
      flash('Refresh failed — check console', '#e57373');
    }
  });
});

function addSite() {
  if (!_currentHost) return;
  const list = (_state.whitelist || []).slice();
  if (!list.includes(_currentHost)) {
    list.push(_currentHost);
    sendPatch({ whitelist: list });
    updateSiteCard(list);
    flash(_currentHost + ' added ✓');
  }
}

function removeSite() {
  if (!_currentHost) return;
  const list = (_state.whitelist || []).filter(e => e.replace(/^www\./, '') !== _currentHost);
  sendPatch({ whitelist: list });
  updateSiteCard(list);
  flash(_currentHost + ' removed');
}

/* ── Init ─────────────────────────────────────────────────── */

chrome.runtime.sendMessage({ type: 'GET_STATE' }, state => {
  _state = state || {};
  setEnabled(!!state.enabled);
  setType(state.mobileType || 'android');
  updateUAPreview(state.mobileType || 'android');

  // Get the active tab's host
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (tabs[0] && tabs[0].url) {
      try {
        _currentHost = new URL(tabs[0].url).hostname.replace(/^www\./, '');
      } catch (_) {}
    }
    updateSiteCard(state.whitelist || []);
  });
});
