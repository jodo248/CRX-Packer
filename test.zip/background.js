/* =========================================================
 * UA Spoofer — background (persistent, MV2)
 * =========================================================
 * Responsibilities
 *  1. Fetch & cache the top-mobile-UA list from jsDelivr.
 *  2. Intercept every outgoing HTTP request and replace the
 *     User-Agent header for whitelisted URLs (webRequest).
 *  3. Answer GET_SPOOF_INFO messages from content scripts
 *     so they can spoof navigator.* in the page JS world.
 * ========================================================= */

'use strict';

const UA_LIST_URL =
  'https://cdn.jsdelivr.net/gh/microlinkhq/top-user-agents@master/src/mobile.json';

const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 h

/* ── Default settings ─────────────────────────────────────── */

const DEFAULTS = {
  enabled:    true,
  mobileType: 'android',   // 'android' | 'iphone'
  whitelist:  [],           // string[] of bare domains
  uaAndroid:  '',
  uaIphone:   '',
  cacheTime:  0,
};

// Live copy kept in memory so webRequest handler is synchronous.
let state = { ...DEFAULTS };

/* ── Storage helpers ──────────────────────────────────────── */

function loadState(cb) {
  chrome.storage.local.get(Object.keys(DEFAULTS), data => {
    Object.assign(state, data);
    if (cb) cb();
  });
}

function saveState(patch, cb) {
  Object.assign(state, patch);
  chrome.storage.local.set(patch, cb);
}

/* ── UA list ──────────────────────────────────────────────── */

function pickUA(agents, type) {
  const kw = type === 'iphone' ? 'iPhone' : 'Android';
  return agents.find(ua => ua.includes(kw)) || agents[0] || '';
}

function refreshCache(cb) {
  fetch(UA_LIST_URL)
    .then(r => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(agents => {
      if (!Array.isArray(agents) || agents.length === 0) throw new Error('empty list');
      saveState({
        uaAndroid: pickUA(agents, 'android'),
        uaIphone:  pickUA(agents, 'iphone'),
        cacheTime: Date.now(),
      }, cb);
      console.log('[UA Spoofer] UA list refreshed.');
    })
    .catch(err => {
      console.warn('[UA Spoofer] Refresh failed:', err.message);
    });
}

function getActiveUA() {
  return state.mobileType === 'iphone' ? state.uaIphone : state.uaAndroid;
}

/* ── Domain matching ──────────────────────────────────────── */

function normalise(domain) {
  return domain.trim().toLowerCase().replace(/^www\./, '');
}

function isWhitelisted(url) {
  if (!url) return false;
  try {
    const host = normalise(new URL(url).hostname);
    return state.whitelist.some(entry => {
      const e = normalise(entry);
      return host === e || host.endsWith('.' + e);
    });
  } catch (_) {
    return false;
  }
}

/* ── webRequest — HTTP header spoofing ────────────────────── */
//
// This fires synchronously before any request leaves the browser,
// so the server receives the spoofed UA. No race-condition possible.

chrome.webRequest.onBeforeSendHeaders.addListener(
  details => {
    if (!state.enabled) return;
    if (!isWhitelisted(details.url)) return;

    const ua = getActiveUA();
    if (!ua) return;

    // Remove whatever UA the browser set, then add ours.
    const headers = (details.requestHeaders || []).filter(
      h => h.name.toLowerCase() !== 'user-agent'
    );
    headers.push({ name: 'User-Agent', value: ua });

    return { requestHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders', 'extraHeaders']   // 'extraHeaders' needed in Chrome 72+
);

/* ── Storage sync ─────────────────────────────────────────── */

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  for (const [key, { newValue }] of Object.entries(changes)) {
    if (key in state) state[key] = newValue;
  }
});

/* ── Message API for content scripts ─────────────────────── */

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'GET_SPOOF_INFO') {
    reply({
      enabled:     state.enabled,
      ua:          getActiveUA(),
      mobileType:  state.mobileType,
      whitelisted: isWhitelisted(sender.url || sender.tab?.url || ''),
    });
    return true; // keep channel open for async reply
  }

  if (msg.type === 'REFRESH_UA') {
    refreshCache(() => reply({ uaAndroid: state.uaAndroid, uaIphone: state.uaIphone }));
    return true;
  }

  if (msg.type === 'GET_STATE') {
    reply({
      enabled:    state.enabled,
      mobileType: state.mobileType,
      whitelist:  state.whitelist,
      uaAndroid:  state.uaAndroid,
      uaIphone:   state.uaIphone,
      cacheTime:  state.cacheTime,
    });
    return true;
  }

  if (msg.type === 'SET_STATE') {
    saveState(msg.patch, () => reply({ ok: true }));
    return true;
  }
});

/* ── Init ─────────────────────────────────────────────────── */

loadState(() => {
  const stale = !state.uaAndroid || (Date.now() - state.cacheTime > CACHE_TTL_MS);
  if (stale) refreshCache();
});
